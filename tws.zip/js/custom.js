(function ($) {
  "use strict";

  $('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:4
        }
    }
})
  // var review = $('.review_part_text');
  // if (review.length) {
  //   review.owlCarousel({
  //     items: 2,
  //     loop: true,
  //     dots: true,
  //     autoplay: true,
  //     margin: 40,
  //     autoplayHoverPause: true,
  //     autoplayTimeout:5000,
  //     nav: false,
  //     responsive: {
  //       0:{
  //         items: 1
  //       },
  //       480:{
  //         items: 1
  //       },
  //       769:{
  //         items: 2
  //       }
  //   }
  //   });
  // }
  $('.popup-youtube, .popup-vimeo').magnificPopup({
    // disableOn: 700,
    type: 'iframe',
    mainClass: 'mfp-fade',
    removalDelay: 160,
    preloader: false,
    fixedContentPos: false
});
  // menu fixed js code
  $(window).scroll(function () {
    var window_top = $(window).scrollTop() + 1;
    if (window_top > 50) {
      $('.main_menu').addClass('menu_fixed animated fadeInDown');
    } else {
      $('.main_menu').removeClass('menu_fixed animated fadeInDown');
    }
  });
  if (document.getElementById('default-select')) {
		$('select').niceSelect();
	}

  // page-scroll
  $('.page-scroll').bind('click', function(event) {
    var $anchor = $(this);
    var headerH = '80';
    $('html, body').stop().animate({
        scrollTop: $($anchor.attr('href')).offset().top - headerH + "px"
    }, 1500, 'easeInOutExpo');
    event.preventDefault();
 });

}(jQuery));